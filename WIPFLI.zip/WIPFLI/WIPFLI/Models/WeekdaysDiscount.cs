﻿namespace WIPFLI.Models
{
    public class WeekdaysDiscount
    {
        public string Day { get; set; }
        public decimal DiscountInPercentage { get; set; }
    }
}
