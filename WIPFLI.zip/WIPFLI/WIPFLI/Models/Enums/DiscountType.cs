﻿namespace WIPFLI.Models
{
    public enum DiscountType
    {
        NoDiscount,
        Unit,
        Flat
    }
}
