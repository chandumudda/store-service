﻿
namespace WIPFLI.Models
{
    public enum UnitType
    {
        Bottle,
        KG,
        Others
    }
}
