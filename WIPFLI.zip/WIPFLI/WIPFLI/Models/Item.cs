﻿namespace WIPFLI.Models
{
    public class Item
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public UnitType UnitType { get; set; }
    }
}
